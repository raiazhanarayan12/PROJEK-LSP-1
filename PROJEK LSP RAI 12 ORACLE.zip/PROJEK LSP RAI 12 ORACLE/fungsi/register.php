<?php
include '../koneksi/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $hash = password_hash($password, PASSWORD_DEFAULT);

    // Cek apakah username sudah digunakan
    $check = $conn->query("SELECT * FROM users WHERE username='$username'");
    if ($check->num_rows > 0) {
        echo "Username sudah digunakan!";
    } else {
        $sql = "INSERT INTO users (username, password) VALUES ('$username', '$hash')";
        if ($conn->query($sql)) {
            echo "Registrasi berhasil. <a href='login.php'>Login sekarang</a>";
        } else {
            echo "Registrasi gagal: " . $conn->error;
        }
    }
}
?>

<h2>Form Register</h2>
<form method="POST">
    Username: <input type="text" name="username" required><br>
    Password: <input type="password" name="password" required><br>
    <button type="submit">Register</button>
</form>
